// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Shared.Localizations;
using Content.Trauma.Shared.Genetics.Console;
using Content.Trauma.Shared.Genetics.Mutations;

namespace Content.Trauma.Client.Genetics.UI;

[GenerateTypedNameReferences]
public sealed partial class GeneticCombiner : BoxContainer
{
    [Dependency] private IEntityManager _entMan = default!;
    [Dependency] private IPrototypeManager _proto = default!;
    private readonly MutationSystem _mutation;

    public event Action? OnScan;
    public event Action<uint>? OnCombine;

    private bool _busy;
    private bool _canCombine;
    private List<string> _names = new();

    public GeneticCombiner()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _mutation = _entMan.System<MutationSystem>();

        Scanner.OnScan += () => OnScan?.Invoke();
        Scanner.OnErrorSet += error =>
        {
            MobContainer.Visible = error == null;
        };

        SequenceButtons.OnSelected += i =>
        {
            UpdateSequence();
        };
        CombineButton.OnPressed += _ =>
        {
            if (SequenceButtons.Index is {} i)
                OnCombine?.Invoke(i);
        };
    }

    public void SetState(List<SequenceState> states)
    {
        SequenceButtons.SetStates(states);
        Scanner.SetSequences(states.Count);
        SequenceButtons.UpdateSequences();
    }

    public void UpdateScanButton()
    {
        Scanner.UpdateScanButton();
    }

    public void UpdateHasScanner(bool hasScanner)
    {
        Scanner.UpdateHasScanner(hasScanner);
    }

    public void SetBusy(bool busy)
    {
        _busy = busy;
        Scanner.SetBusy(busy);
        UpdateButton();
    }

    public void SetMob(EntityUid? mob)
    {
        Scanner.SetMob(mob);
    }

    public void UpdateDiskMutation(EntProtoId<MutationComponent>? mutation)
    {
        if (mutation is {} id)
        {
            DiskMutation.Text = Loc.GetString("genetics-console-combine-catalyst", ("mutation", _proto.Index(id).Name));
            var recipes = _mutation.GetPossibleRecipes(id);
            _canCombine = recipes.Count > 0;
            _names.Clear();
            foreach (var recipe in recipes)
            {
                var result = _proto.Index(recipe).Result;
                _names.Add(_proto.Index(result).Name);
            }
            var results = ContentLocalizationManager.FormatList(_names);
            DiskRecipes.Text = _canCombine
                ? Loc.GetString("genetics-console-combine-results", ("results", results))
                : Loc.GetString("genetics-console-combine-no-results");
            DiskRecipes.Visible = true;
        }
        else
        {
            DiskMutation.Text = Loc.GetString("genetics-console-disk-empty");
            DiskRecipes.Visible = false;
            _canCombine = false;
        }

        UpdateButton();
    }

    private void UpdateSequence()
    {
        UpdateButton();
        Info.Update(SequenceButtons);
        NoSequence.Visible = !Info.Visible;
    }

    private void UpdateButton()
    {
        CombineButton.Disabled = _busy ||
            SequenceButtons.Index == null ||
            !_canCombine;
    }
}
