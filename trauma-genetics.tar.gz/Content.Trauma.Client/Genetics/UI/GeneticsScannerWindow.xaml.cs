// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Client.UserInterface.Controls;
using Content.Trauma.Shared.Genetics.Console;
using Content.Trauma.Shared.Genetics.Mutations;
using Robust.Shared.Timing;

namespace Content.Trauma.Client.Genetics.UI;

[GenerateTypedNameReferences]
public sealed partial class GeneticsScannerWindow : FancyWindow
{
    [Dependency] private IEntityManager _entMan = default!;
    [Dependency] private IGameTiming _timing = default!;
    private readonly ScannedGenomeSystem _genome;

    public event Action? OnScan;
    public event Action<uint?>? OnPrint;

    private EntityQuery<GeneticsScannerComponent> _query;
    private EntityQuery<GeneticsPrintoutComponent> _printQuery;

    public GeneticsScannerWindow()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _genome = _entMan.System<ScannedGenomeSystem>();

        _query = _entMan.GetEntityQuery<GeneticsScannerComponent>();
        _printQuery = _entMan.GetEntityQuery<GeneticsPrintoutComponent>();

        Sequencer.MakeReadonly();
        Sequencer.OnScan += () => OnScan?.Invoke();
        Sequencer.OnPrintScan += () => OnPrint?.Invoke(null);
        Sequencer.OnPrintSequence += i => OnPrint?.Invoke(i);

        Sequencer.UpdateHasScanner(true); // this is the scanner
    }

    private EntityUid _uid;
    private EntityUid? _mob;
    private bool _busy;
    private bool _scanned;

    protected override void FrameUpdate(FrameEventArgs args)
    {
        base.FrameUpdate(args);

        if (_query.TryComp(_uid, out var comp))
            Update(comp);
        if (_printQuery.TryComp(_uid, out var print))
            UpdatePrint(print);
    }

    public void SetEntity(EntityUid uid)
    {
        if (!_query.TryComp(uid, out var comp))
            return;

        _uid = uid;
        Update(comp);
        Sequencer.UpdateHasPrintout(_printQuery.HasComp(uid));
    }

    public void UpdateState(GeneticsConsoleState state)
    {
        Sequencer.SetState(state.Sequences);
    }

    private void Update(GeneticsScannerComponent comp)
    {
        if (comp.ScannedMob != _mob)
            UpdateMob(_mob = comp.ScannedMob);
        if (comp.Busy != _busy)
            Sequencer.SetBusy(_busy = comp.Busy);
    }

    private void UpdatePrint(GeneticsPrintoutComponent comp)
    {
        Sequencer.UpdatePrintCooldown(_timing.CurTime < comp.NextPrint);
    }

    private void UpdateMob(EntityUid? mob)
    {
        Sequencer.SetMob(mob);
        if (mob is not {} uid)
            return;

        var scanned = _genome.IsScanned(uid);
        if (scanned != _scanned)
        {
            _scanned = scanned;
            Sequencer.UpdateScanButton();
        }
    }
}
