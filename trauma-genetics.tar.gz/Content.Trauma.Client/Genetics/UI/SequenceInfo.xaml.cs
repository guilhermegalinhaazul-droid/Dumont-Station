// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Trauma.Shared.Genetics.Mutations;

namespace Content.Trauma.Client.Genetics.UI;

[GenerateTypedNameReferences]
public sealed partial class SequenceInfo : BoxContainer
{
    [Dependency] private IEntityManager _entMan = default!;
    [Dependency] private IPrototypeManager _proto = default!;
    private readonly MutationSystem _mutation;

    public SequenceInfo()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _mutation = _entMan.System<MutationSystem>();
    }

    public void Update(SequenceButtons buttons)
    {
        Visible = buttons.Index != null;

        if (buttons.Sequence is not {} sequence)
            return;

        if (sequence.Mutation is {} id)
        {
            var proto = _proto.Index<EntityPrototype>(id);
            var instability = _mutation.AllMutations[id].Instability;
            MutationName.Text = proto.Name;
            MutationDesc.Text = proto.Description;
            MutationInstability.Text = instability.ToString();
        }
        else
        {
            MutationName.Text = Loc.GetString("genetics-console-mutation-name-placeholder", ("number", sequence.Number));
            MutationDesc.Text = Loc.GetString("generic-unknown-title");
            MutationInstability.Text = Loc.GetString("generic-unknown-title");
        }
    }
}
