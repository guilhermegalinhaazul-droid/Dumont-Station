// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Shared.Localizations;
using Content.Trauma.Shared.Genetics;
using Content.Trauma.Shared.Genetics.Console;

namespace Content.Trauma.Client.Genetics.UI;

[GenerateTypedNameReferences]
public sealed partial class GeneticEnzymes : BoxContainer
{
    [Dependency] private IEntityManager _entMan = default!;

    public event Action? OnSave;
    public event Action? OnApply;

    private readonly string _na;
    private bool _busy;
    private bool _cooldown;
    private bool _scanned;
    private Entity<GeneticsDiskComponent>? _disk;
    private string? _mobName;
    private UniqueEnzymes? _enzymes;

    public GeneticEnzymes()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _na = Loc.GetString("generic-not-available-shorthand");

        SaveButton.OnPressed += _ => OnSave?.Invoke();
        ApplyButton.OnPressed += _ => OnApply?.Invoke();
    }

    public void SetBusy(bool busy)
    {
        _busy = busy;
        UpdateSaveButton();
        UpdateApplyButton();
    }

    public void SetMob(EntityUid? mob)
    {
        _mobName = _entMan.GetComponentOrNull<MetaDataComponent>(mob)?.EntityName;
        MobNameLabel.Text = _mobName ?? _na;
        UpdateSaveButton();
    }

    public void UpdateCooldown(bool cooldown)
    {
        _cooldown = cooldown;
        UpdateApplyButton();
    }

    public void UpdateDisk(Entity<GeneticsDiskComponent>? disk)
    {
        _disk = disk;
        DiskLabel.Text = _entMan.GetComponentOrNull<MetaDataComponent>(disk)?.EntityName
            ?? Loc.GetString("genetics-console-no-disk");
        UpdateEnzymes(disk?.Comp.Enzymes);
        UpdateSaveButton();
    }

    public void UpdateScanned(bool scanned)
    {
        _scanned = scanned;
        UpdateApplyButton();
    }

    public void UpdateEnzymes(UniqueEnzymes? enzymes)
    {
        if (_enzymes?.Name == enzymes?.Name)
            return;

        _enzymes = enzymes;
        UpdateSaveButton();
        UpdateApplyButton();

        DiskNameLabel.Text = enzymes?.Name ?? _na;
        DiskSexLabel.Text = enzymes?.Sex is {} sex ? Loc.GetString($"humanoid-profile-editor-sex-{sex.ToString().ToLower()}-text") : _na;
        DiskEyeLabel.Text = ColorString(enzymes?.EyeColor);
        DiskSkinLabel.Text = ColorString(enzymes?.SkinColor);
    }

    private string ColorString(Color? color)
        => color is {} col
            ? Loc.GetString("genetics-console-color", ("r", (int) (col.R * 255)), ("g", (int) (col.G * 255)), ("b", (int) (col.B * 255)))
            : _na;

    private void UpdateSaveButton()
    {
        SaveButton.Disabled = _busy || _disk == null || _enzymes?.Name == _mobName;
    }

    private void UpdateApplyButton()
    {
        ApplyButton.Disabled = _busy || _cooldown || !_scanned || _mobName == null || _enzymes == null;
    }
}
