// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Client.UserInterface.Controls;
using Content.Shared.Mobs.Components;
using Content.Trauma.Shared.Genetics.Console;
using Content.Trauma.Shared.Genetics.Mutations;
using Robust.Shared.Timing;

namespace Content.Trauma.Client.Genetics.UI;

[GenerateTypedNameReferences]
public sealed partial class GeneticsConsoleWindow : FancyWindow
{
    [Dependency] private IEntityManager _entMan = default!;
    [Dependency] private IGameTiming _timing = default!;
    private readonly GeneticsDiskSystem _disk;
    private readonly MutationSystem _mutation;
    private readonly ScannedGenomeSystem _genome;

    public event Action? OnSelectServer;
    public event Action? OnScan;
    public event Action? OnScramble;
    public event Action<uint, uint, GeneticsCycle>? OnSetBase;
    public event Action<uint>? OnWriteMutation;
    public event Action<uint>? OnSequence;
    public event Action<uint>? OnResetSequence;
    public event Action<uint>? OnPrint;
    public event Action<uint>? OnCombine;
    public event Action? OnSaveEnzymes;
    public event Action? OnApplyEnzymes;

    private EntityQuery<GeneticsConsoleComponent> _query;
    private EntityQuery<GeneticsConsoleEnzymesComponent> _enzymesQuery;
    private EntityQuery<GeneticsScannerComponent> _scannerQuery;
    private EntityQuery<MobStateComponent> _mobQuery;

    private EntityUid _uid;
    private bool? _hasScanner;
    private EntityUid? _mob;
    private Entity<GeneticsDiskComponent>? _currentDisk;
    private EntProtoId<MutationComponent>? _diskMutation;
    private bool _busy;
    private bool _scanned;
    private int? _damage;
    private int _instability;
    private int _scrambleCooldown;
    private bool _writeCooldown;
    private bool _printCooldown;
    private bool _enzymesCooldown;

    public GeneticsConsoleWindow()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _disk = _entMan.System<GeneticsDiskSystem>();
        _mutation = _entMan.System<MutationSystem>();
        _genome = _entMan.System<ScannedGenomeSystem>();

        _query = _entMan.GetEntityQuery<GeneticsConsoleComponent>();
        _enzymesQuery = _entMan.GetEntityQuery<GeneticsConsoleEnzymesComponent>();
        _scannerQuery = _entMan.GetEntityQuery<GeneticsScannerComponent>();
        _mobQuery = _entMan.GetEntityQuery<MobStateComponent>();

        ServerButton.OnPressed += _ => OnSelectServer?.Invoke();

        Sequencer.OnScan += () => OnScan?.Invoke();
        ScrambleButton.OnPressed += _ => OnScramble?.Invoke();
        Sequencer.OnSetBase += (s, i, c) => OnSetBase?.Invoke(s, i, c);
        Sequencer.OnWriteMutation += i => OnWriteMutation?.Invoke(i);
        Sequencer.OnSequence += i => OnSequence?.Invoke(i);
        Sequencer.OnResetSequence += i => OnResetSequence?.Invoke(i);

        Storage.OnPrint += p => OnPrint?.Invoke(p);

        Combiner.OnScan += () => OnScan?.Invoke();
        Combiner.OnCombine += i => OnCombine?.Invoke(i);

        Enzymes.OnSave += () => OnSaveEnzymes?.Invoke();
        Enzymes.OnApply += () => OnApplyEnzymes?.Invoke();
    }

    protected override void FrameUpdate(FrameEventArgs args)
    {
        base.FrameUpdate(args);

        if (!_query.TryComp(_uid, out var comp) ||
            !_scannerQuery.TryComp(_uid, out var scanner) ||
            !_enzymesQuery.TryComp(_uid, out var enzymes))
            return;

        Update(comp, scanner, enzymes);
        UpdateDisk(_disk.GetDisk(_uid));
    }

    public void SetEntity(EntityUid uid)
    {
        if (!_query.TryComp(uid, out var comp) ||
            !_scannerQuery.TryComp(uid, out var scanner) ||
            !_enzymesQuery.TryComp(uid, out var enzymes))
            return;

        _uid = uid;
        Update(comp, scanner, enzymes);
        Storage.SetConsole(comp);
    }

    public void UpdateState(GeneticsConsoleState state)
    {
        Sequencer.SetState(state.Sequences);
        Combiner.SetState(state.Sequences);
    }

    private void Update(GeneticsConsoleComponent comp, GeneticsScannerComponent scanner, GeneticsConsoleEnzymesComponent enzymes)
    {
        var hasScanner = scanner.Scanner != null;
        if (hasScanner != _hasScanner)
            UpdateScanner((_hasScanner = hasScanner) == true);
        if (scanner.ScannedMob != _mob)
            UpdateMob(_mob = scanner.ScannedMob);
        if (scanner.Busy != _busy)
            UpdateBusy(_busy = scanner.Busy);

        UpdateScrambleCooldown(comp.NextScramble);
        UpdateWriteCooldown(comp.NextWrite);
        UpdatePrintCooldown(comp.NextPrint);
        UpdateEnzymesCooldown(enzymes.NextApply);

        if (_mob is not {} mob)
            return;

        var damage = _mutation.GetGeneticDamage(mob);
        if (damage != _damage)
        {
            _damage = damage;
            UpdateIntegrity();
        }
        var instability = _mutation.GetInstability(mob);
        if (instability != _instability)
        {
            _instability = instability;
            UpdateInstability();
        }
        var scanned = _genome.IsScanned(mob);
        if (scanned != _scanned)
        {
            _scanned = scanned;
            Sequencer.UpdateScanButton();
            Combiner.UpdateScanButton();
            Enzymes.UpdateScanned(scanned);
        }
    }

    private void UpdateDisk(Entity<GeneticsDiskComponent>? disk)
    {
        var mutation = disk?.Comp.Mutation;
        if (_diskMutation != mutation)
        {
            _diskMutation = mutation;
            Storage.UpdateDiskMutation(mutation);
            Combiner.UpdateDiskMutation(mutation);
        }
        Enzymes.UpdateEnzymes(disk?.Comp.Enzymes); // internal change detection

        if (_currentDisk == disk)
            return;

        _currentDisk = disk;

        Sequencer.UpdateDisk(disk);
        Storage.UpdateDisk(disk);
        Enzymes.UpdateDisk(disk);
    }

    private void UpdateScanner(bool hasScanner)
    {
        Sequencer.UpdateHasScanner(hasScanner);
        Combiner.UpdateHasScanner(hasScanner);
        UpdateMob(hasScanner ? _mob : null);
        if (!hasScanner)
            MobStatus.Text = Loc.GetString("genetics-console-no-scanner");
    }

    private void UpdateMob(EntityUid? uid)
    {
        MobView.SetEntity(uid);
        UpdateScrambleDisabled();
        Sequencer.SetMob(uid);
        Combiner.SetMob(uid);
        Enzymes.SetMob(uid);
        if (_mobQuery.TryComp(uid, out var mob))
        {
            MobName.Text = _entMan.GetComponent<MetaDataComponent>(uid.Value).EntityName;
            MobStatus.Text = Loc.GetString($"mob-state-{mob.CurrentState}");
        }
        else
        {
            MobName.Text = Loc.GetString("genetics-console-no-subject");
            MobStatus.Text = Loc.GetString("generic-not-available-shorthand");
        }
        UpdateInstability();
        UpdateIntegrity();
    }

    private void UpdateScrambleDisabled()
    {
        ScrambleContainer.Visible = _mob != null;
        ScrambleButton.Disabled = _mob is not {} mob ||
            !_genome.IsScanned(mob) ||
            _scrambleCooldown > 0;
    }

    private bool OnCooldown(TimeSpan next)
        => _timing.CurTime < next;

    private void UpdateScrambleCooldown(TimeSpan nextScramble)
    {
        var cooldown = (int) (nextScramble - _timing.CurTime).TotalSeconds;
        if (cooldown < 0)
            cooldown = 0;
        if (cooldown == _scrambleCooldown)
            return;

        _scrambleCooldown = cooldown;
        ScrambleButton.Text = cooldown > 0
            ? Loc.GetString("genetics-console-scramble-cooldown", ("cooldown", cooldown))
            : Loc.GetString("genetics-console-scramble");
        UpdateScrambleDisabled();
    }

    private void UpdateWriteCooldown(TimeSpan nextWrite)
    {
        var cooldown = OnCooldown(nextWrite);
        if (cooldown == _writeCooldown)
            return;

        Sequencer.UpdateWriteCooldown(_writeCooldown = cooldown);
    }

    private void UpdatePrintCooldown(TimeSpan nextPrint)
    {
        var cooldown = OnCooldown(nextPrint);
        if (cooldown == _printCooldown)
            return;

        Storage.UpdateCooldowns(_printCooldown = cooldown);
    }

    private void UpdateEnzymesCooldown(TimeSpan nextApply)
    {
        var cooldown = OnCooldown(nextApply);
        if (cooldown == _enzymesCooldown)
            return;

        Enzymes.UpdateCooldown(_enzymesCooldown = cooldown);
    }

    private void UpdateInstability()
    {
        MobInstability.Text = $"{_instability}%";
    }

    private void UpdateIntegrity()
    {
        MobIntegrity.Text = _damage is {} damage
            ? Math.Max(100 - damage, 0).ToString()
            : Loc.GetString("generic-not-available-shorthand");
    }

    private void UpdateBusy(bool busy)
    {
        Sequencer.SetBusy(busy);
        Combiner.SetBusy(busy);
        Enzymes.SetBusy(busy);
    }
}
