// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Trauma.Shared.Genetics.Mutations;

namespace Content.Trauma.Client.Genetics.UI;

/// <summary>
/// Error section to show when the console doesn't have a scanned mob.
/// Includes a scan button.
/// </summary>
[GenerateTypedNameReferences]
public sealed partial class GeneticScanner : BoxContainer
{
    [Dependency] private IEntityManager _entMan = default!;
    private readonly ScannedGenomeSystem _genome;

    public event Action? OnScan;
    public event Action<LocId?>? OnErrorSet;

    private EntityUid? _mob;
    private bool _hasScanner;
    private bool _busy;
    private bool _blank;

    public GeneticScanner()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _genome = _entMan.System<ScannedGenomeSystem>();

        ScanButton.OnPressed += _ => OnScan?.Invoke();
    }

    public void SetMob(EntityUid? mob)
    {
        _mob = mob;
        UpdateScanButton();
    }

    public void SetBusy(bool busy)
    {
        _busy = busy;
        UpdateScanButton();
    }

    public void UpdateScanButton()
    {
        var scanned = _mob is {} uid && _genome.IsScanned(uid);
        ScanButton.Disabled = !_hasScanner || _mob == null || scanned || _busy;
        if (!_hasScanner)
            SetError("genetics-console-no-scanner");
        else if (_mob == null)
            SetError("genetics-console-sequencer-no-subject");
        else if (!scanned) // button should be enabled for this
            SetError("genetics-console-sequencer-not-scanned");
        else if (_blank)
            SetError("genetics-console-sequencer-no-sequences");
        else if (!_busy) // ready to work on
            SetError(null);
        // retain previous message if busy
    }

    public void SetError(LocId? error)
    {
        Visible = error != null;
        if (error is {} id)
            ErrorLabel.Text = Loc.GetString(id);
        OnErrorSet?.Invoke(error);
    }

    public void UpdateHasScanner(bool hasScanner)
    {
        _hasScanner = hasScanner;
        UpdateScanButton();
    }

    public void SetSequences(int count)
    {
        _blank = count == 0;
        UpdateScanButton();
    }
}
