// SPDX-License-Identifier: AGPL-3.0-or-later

using Content.Trauma.Shared.Genetics.Console;
using Content.Trauma.Shared.Genetics.Mutations;

namespace Content.Trauma.Client.Genetics.UI;

[GenerateTypedNameReferences]
public sealed partial class GeneticSequencer : BoxContainer
{
    [Dependency] private IEntityManager _entMan = default!;
    private readonly ScannedGenomeSystem _genome;

    public event Action? OnScan;
    public event Action<uint, uint, GeneticsCycle>? OnSetBase;
    public event Action<uint>? OnWriteMutation;
    public event Action<uint>? OnSequence;
    public event Action<uint>? OnResetSequence;
    public event Action? OnPrintScan;
    public event Action<uint>? OnPrintSequence;

    private EntityUid? _mob;
    private Entity<GeneticsDiskComponent>? _disk;
    private bool _writeCooldown;

    public GeneticSequencer()
    {
        IoCManager.InjectDependencies(this);
        RobustXamlLoader.Load(this);

        _genome = _entMan.System<ScannedGenomeSystem>();

        Scanner.OnScan += () => OnScan?.Invoke();
        Scanner.OnErrorSet += error =>
        {
            MobContainer.Visible = error == null;
        };

        Puzzle.OnSetBase += (i, c) =>
        {
            if (SequenceButtons.Index is {} s)
                OnSetBase?.Invoke(s, i, c);
        };
        Puzzle.OnSequence += () =>
        {
            if (SequenceButtons.Index is {} s)
                OnSequence?.Invoke(s);
        };
        Puzzle.OnResetSequence += () =>
        {
            if (SequenceButtons.Index is {} s)
                OnResetSequence?.Invoke(s);
        };

        WriteButton.OnPressed += _ =>
        {
            if (SequenceButtons.Index is {} s)
                OnWriteMutation?.Invoke(s);
        };

        SequenceButtons.OnSelected += i =>
        {
            UpdateSequence();
            UpdateWriteButton();
        };

        PrintScanButton.OnPressed += _ => OnPrintScan?.Invoke();
        PrintSequenceButton.OnPressed += _ =>
        {
            if (SequenceButtons.Index is {} s)
                OnPrintSequence?.Invoke(s);
        };
    }

    public void MakeReadonly()
    {
        WriteButton.Visible = false;
        Puzzle.MakeReadonly();
    }

    public void SetMob(EntityUid? mob)
    {
        _mob = mob;
        Scanner.SetMob(mob);
    }

    public void SetBusy(bool busy)
    {
        Scanner.SetBusy(busy);
        Puzzle.SetBusy(busy);
    }

    private void UpdateSequence()
    {
        Info.Update(SequenceButtons);
        NoSequence.Visible = !Info.Visible;
        Puzzle.Visible = Info.Visible;

        if (SequenceButtons.Sequence is not {} sequence)
            return;

        Puzzle.SetSequenced(sequence.Mutation != null);
        Puzzle.SetBases(sequence.Bases, sequence.OriginalBases);
    }

    public void SetState(List<SequenceState> states)
    {
        SequenceButtons.SetStates(states);
        Scanner.SetSequences(states.Count);
        SequenceButtons.UpdateSequences();
        UpdateSequence();
        UpdateWriteButton();
    }

    public void UpdateScanButton()
    {
        Scanner.UpdateScanButton();
    }

    public void UpdateHasScanner(bool hasScanner)
    {
        Scanner.UpdateHasScanner(hasScanner);
    }

    public void UpdateHasPrintout(bool hasPrintout)
    {
        PrintScanButton.Visible = hasPrintout;
        PrintSequenceButton.Visible = hasPrintout;
    }

    public void UpdateDisk(Entity<GeneticsDiskComponent>? disk)
    {
        _disk = disk;
        UpdateWriteButton();
    }

    public void UpdateWriteCooldown(bool cooldown)
    {
        _writeCooldown = cooldown;
        UpdateWriteButton();
    }

    public void UpdatePrintCooldown(bool cooldown)
    {
        PrintScanButton.Disabled = cooldown;
        PrintSequenceButton.Disabled = cooldown;
    }

    private void UpdateWriteButton()
    {
        WriteButton.Disabled = _disk is not {} disk ||
            SequenceButtons.Sequence?.Mutation is not {} mutation ||
            disk.Comp.Mutation == mutation ||
            _writeCooldown;
    }
}
